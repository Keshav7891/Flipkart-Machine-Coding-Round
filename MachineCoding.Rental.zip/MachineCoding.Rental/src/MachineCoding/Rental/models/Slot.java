package MachineCoding.Rental.models;

public class Slot {
	int startDay;
	int startMonth;
	int startYear;
	
	int endDay;
	int endMonth;
	int endYear;
	
	int from;
	int to;
}
